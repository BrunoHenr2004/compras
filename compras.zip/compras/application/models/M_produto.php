<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_produto extends CI_Model {

    public function inserir($descricao, $unidadeMedida, $estoqueMinimo, $estoqueMaximo, $usuarioLogin) {
        try {
            //Verificando se a descrição já existe
            $this->db->where('descricao', $descricao);
            $descricao_existente = $this->db->get('produtos');
    
            if($descricao_existente->num_rows() > 0) {
                return array('codigo' => 2,
                             'msg' => 'Descrição já cadastrada.');
            }
    
            //Verificando se a unidade de medida existe
            $this->db->where('cod_unidade', $unidadeMedida);
            $unidade_existente = $this->db->get('unid_medida');
    
            if($unidade_existente->num_rows() == 0) {
                return array('codigo' => 3,
                             'msg' => 'Unidade de medida não encontrada.');
            }
    
            $sql = "insert into produtos (descricao, unid_medida, estoq_minimo, estoq_maximo, usucria, estatus)
                    values ('$descricao', $unidadeMedida, $estoqueMinimo, $estoqueMaximo, '$usuarioLogin', '')";
    
            $this->db->query($sql);
    
            if($this->db->affected_rows() > 0) {

                $this->load->model('M_log');

                $retorno_log = $this->M_log->inserirLog($usuarioLogin, $sql);
    
                if($retorno_log['codigo'] == 1) {
                    $dados = array('codigo' => 1, 'msg' => 'Produto cadastrado corretamente.');
                } else {
                    $dados = array('codigo' => 7, 
                                   'msg' => 'Houve algum problema no salvamento do log, porém, o produto foi inserido corretamente.');
                }
            } else {
                $dados = array('codigo' => 6, 
                               'msg' => 'Houve algum problema na inserção na tabela de produtos.');
            }
        } catch(Exception $e) {
            $dados = array('codigo' => 0, 
                           'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ', $e->getMessage());
        }
    
        //Retorna as informações tratadas
        return $dados;
    }

    public function consultar($cod_produto, $descricao, $estoqueMinimo, $estoqueMaximo) {
        try {
            $sql = "select * from produtos where estatus = ''";
    
            if($cod_produto != '' && $cod_produto != '0') {
                $sql .= " and cod_produtos = '$cod_produto'";
            }
    
            if($descricao != '') {
                $sql .= " and descricao like '%$descricao%'";
            }
    
            if($estoqueMinimo != '') {
                $sql .= " and estoq_minimo >= $estoqueMinimo";
            }
    
            if($estoqueMaximo != '') {
                $sql .= " and estoq_maximo <= $estoqueMaximo";
            }
    
            $retorno = $this->db->query($sql);
    
            if($retorno->num_rows() > 0) {
                $dados = array('codigo' => 1,
                               'msg' => 'Consulta realizada com sucesso',
                               'dados' => $retorno->result()
                );
            } else {
                $dados = array('codigo' => 6,
                               'msg' => 'Dados não encontrados');
            }
        } catch(Exception $e) {
            $dados = array('codigo' => 0,
                           'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ', $e->getMessage()
            );
        }
    
        //Retorna os dados processados
        return $dados;
    }

    public function alterar($cod_produto, $descricao, $estoqueMinimo, $estoqueMaximo, $usuarioLogin) {
        try {
            $this->load->model('M_produto');

            //Verificando se o usuário existe
            if(!$this->usuarioExiste($usuarioLogin)) {
                return array('codigo' => 4,
                             'msg' => 'Usuário logado no sistema inexistente.');
            }
    
            //Verificando se o código do produto foi informado
            if(trim($cod_produto) == '' || trim($cod_produto) == '0') {
                return array('codigo' => 2,
                             'msg' => 'Código do produto não informado.');
            }
    
            //Verificando os valores atuais do registro
            $this->db->where('cod_produtos', $cod_produto);
            $query = $this->db->get('produtos');
            $registro_atual = $query->row();
    
            if(!$registro_atual) {
                return array('codigo' => 6, 
                             'msg' => 'Produto não encontrado para o código fornecido.');
            }
    
            //Construindo a query de atualização com base nos parâmetros fornecidos
            $updates = array();
            if(trim($descricao) != '' && $descricao != $registro_atual->descricao) {
                $updates['descricao'] = $descricao;
            }
            if(trim($estoqueMinimo) != '' && $estoqueMinimo != $registro_atual->estoq_minimo) {
                $updates['estoq_minimo'] = $estoqueMinimo;
            }
            if(trim($estoqueMaximo) != '' && $estoqueMaximo != $registro_atual->estoq_maximo) {
                $updates['estoq_maximo'] = $estoqueMaximo;
            }
    
            //Verificando se há alterações a serem feitas
            if(empty($updates)) {
                return array('codigo' => 10,
                             'msg' => 'Nenhuma alteração foi feita. Os valores já são os mesmos.');
            }
    
            $this->db->where('cod_produtos', $cod_produto);
            $this->db->update('produtos', $updates);
    
            if($this->db->affected_rows() > 0) {

                $this->load->model('M_log');

                $query_log = $this->db->last_query();

                $retorno_log = $this->M_log->inserirLog($usuarioLogin, $query_log);
    
                if($retorno_log['codigo'] == 1) {
                    $dados = array('codigo' => 1,
                                   'msg' => 'Produto atualizado corretamente.');
                } else {
                    $dados = array('codigo' => 7,
                                   'msg' => 'Houve algum problema no salvamento do log, porém, o produto foi alterado corretamente.'
                    );
                }
            } else {
                $dados = array('codigo' => 6,
                               'msg' => 'Houve algum problema na alteração na tabela de produtos.');
            }
        } catch(Exception $e) {
            $dados = array('codigo' => 0,
                           'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ', $e->getMessage()
            );
        }
    
        //Retorna os dados processados
        return $dados;
    }

    public function desativar($cod_produto, $usuarioLogin) {
        try {
            //Verificando se o código do produto foi informado
            if(trim($cod_produto) == '' || trim($cod_produto) == '0') {
                return array('codigo' => 2,
                             'msg' => 'Código do produto não informado.');
            }
    
            //Verificando se o registro atual existe e está ativo
            $this->db->where('cod_produtos', $cod_produto);
            $this->db->where('estatus', '');
            $query = $this->db->get('produtos');
    
            if($query->num_rows() == 0) {
                return array('codigo' => 6, 
                             'msg' => 'Produto não encontrado ou já desativado.');
            }
    
            //Desativando o produto
            $this->db->set('estatus', 'D');
            $this->db->set('usucria', $usuarioLogin);
            $this->db->where('cod_produtos', $cod_produto);
            $this->db->update('produtos');
    
            if($this->db->affected_rows() > 0) {

                $this->load->model('M_log');

                $query_log = $this->db->last_query();
                
                $retorno_log = $this->M_log->inserirLog($usuarioLogin, $query_log);
    
                if($retorno_log['codigo'] == 1) {
                    $dados = array('codigo' => 1,
                                   'msg' => 'Produto desativado corretamente.');
                } else {
                    $dados = array('codigo' => 8,
                                   'msg' => 'Houve algum problema no salvamento do log, porém, o produto foi desativado corretamente.'
                    );
                }
            } else {
                $dados = array('codigo' => 7,
                               'msg' => 'Houve algum problema na desativação do produto.');
            }
        } catch(Exception $e) {
            $dados = array('codigo' => 0,
                           'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ', $e->getMessage()
            );
        }
    
        //Retorna os dados processados
        return $dados;
    }

    public function usuarioExiste($usuarioLogin) {
        $this->db->where('usuario', trim($usuarioLogin));
        $query = $this->db->get('usuarios');
        return $query->num_rows() > 0;
    }
}
?>