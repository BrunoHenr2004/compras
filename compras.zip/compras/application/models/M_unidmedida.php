<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_unidmedida extends CI_Model {

    public function inserir($sigla, $descricao, $usuarioLogin) {
        try {
            //Verificando se a sigla já existe
            $this->db->where('sigla', $sigla);
            $sigla_existente = $this->db->get('unid_medida');

            if($sigla_existente->num_rows() > 0) {
                return array('codigo' => 2, 
                             'msg' => 'Sigla já cadastrada');
            }

            //Verificando se a descrição já existe
            $this->db->where('descricao', $descricao);
            $descricao_existente = $this->db->get('unid_medida');

            if($descricao_existente->num_rows() > 0) {
                return array('codigo' => 3,
                             'msg' => 'Descrição já cadastrada');
            }

            $sql = "insert into unid_medida (sigla, descricao, usucria)
                    values ('$sigla', '$descricao', '$usuarioLogin')";

            $this->db->query($sql);

            if($this->db->affected_rows() > 0) {

                $this->load->model('M_log');

                $retorno_log = $this->M_log->inserirLog($usuarioLogin, $sql);

                if($retorno_log['codigo'] == 1) {
                    $dados = array('codigo' => 1,
                                   'msg' => 'Unidade de Medida cadastrada corretamente');
                } else {
                    $dados = array('codigo' => 7,
                                   'msg' => 'Houve algum problema no salvamento do log, porém, a Unidade de Medida foi inserida corretamente');
                }
            } else {
                $dados = array('codigo' => 6,
                               'msg' => 'Houve algum problema na inserção na tabela de unidade de medida');
            }
        } catch(Exception $e) {
            $dados = array('codigo' => 00,
                           'msg' => 'ATENCAO: O seguinte erro aconteceu ->', $e->getMessage(), "\n");
        }

        //Envia o array $dados com as informações tratadas acima pela estrutura de decisão if
        return $dados;
    }

    public function consultar($cod_unidade, $sigla, $descricao) {
        try {
            $sql = "select * from unid_medida where estatus = '' ";

            if($cod_unidade != '' && $cod_unidade != '0') {
                $sql = $sql . " and cod_unidade = '$cod_unidade' ";
            }

            if($sigla != '') {
                $sql = $sql . " and sigla = '$sigla' ";
            }

            if($descricao != '') {
                $sql = $sql . " and descricao like '%$descricao%' ";
            }

            $retorno = $this->db->query($sql);

            if($retorno->num_rows() > 0) {
                $dados = array('codigo' => 1,
                               'msg' => 'Consulta realizada com sucesso',
                               'dados' => $retorno->result());
            } else {
                    $dados = array('codigo' => 6,
                                   'msg' => 'Dados não encontrados');
            }
        } catch(Exception $e) {
            $dados = array('codigo' => 00,
                           'msg' => 'ATENCAO: O seguinte erro aconteceu ->', $e->getMessage(), "\n");
        }

        //Envia o array $dados com as informações tratadas acima pela estrutura de decisão if
        return $dados;
    }

    public function alterar($cod_unidade, $sigla, $descricao, $usuarioLogin) {
        try {
            $this->load->model('M_unidmedida');

            //Verificando se o usuário existe
            if(!$this->usuarioExiste($usuarioLogin)) {
            return array('codigo' => 4,
                         'msg' => 'Usuário logado no sistema inexistente.');
            }

            //Verificando se a sigla foi informada
            if(trim($sigla) == '') {
                return array('codigo' => 8, 
                             'msg' => 'Sigla não informada.');
            }

            //Verificando se a descrição foi informada
            if(trim($descricao) == '') {
                return array('codigo' => 9,
                             'msg' => 'Descrição não informada.');
            }

            //Verificando os valores atuais do registro
            $this->db->where('cod_unidade', $cod_unidade);
            $query = $this->db->get('unid_medida');
            $registro_atual = $query->row();

            if($registro_atual) {
                //Comparando os valores atuais com os novos
                if(trim($sigla) == $registro_atual->sigla && trim($descricao) == $registro_atual->descricao) {
                    return array('codigo' => 10, 
                                 'msg' => 'Nenhuma alteração foi feita. Os valores já são os mesmos.');
                }
        } else {
            return array('codigo' => 6,
                         'msg' => 'Registro não encontrado para o código fornecido.');
        }

            if(trim($sigla) != '' && trim($descricao) != '') {
                $sql = "update unid_medida set sigla = '$sigla', descricao = '$descricao' where cod_unidade = $cod_unidade";
            } elseif(trim($sigla) != '') {
                $sql = "update unid_medida set sigla = '$sigla' where cod_unidade = $cod_unidade";
            } else {
                $sql = "update unid_medida set descricao = '$descricao' where cod_unidade = $cod_unidade";
            }

            $this->db->query($sql);

            if($this->db->affected_rows() > 0) {

                $this->load->model('M_log');

                $retorno_log = $this->M_log->inserirLog($usuarioLogin, $sql);

                if($retorno_log['codigo'] == 1) {
                    $dados = array('codigo' => 1,
                                   'msg' => 'Unidade de Medida atualizada corretamente');
                } else {
                    $dados = array('codigo' => 7,
                                   'msg' => 'Houve algum problema no salvamento do log, porém, a Unidade de Medida foi alterada corretamente');
                }
            } else {
                $dados = array('codigo' => 6,
                               'msg' => 'Houve algum problema na alteração na tabela de unidade de medida');
            }
        } catch(Exception $e) {
            $dados = array('codigo' => 00,
                           'msg' => 'ATENCAO: O seguinte erro aconteceu ->', $e->getMessage(), "\n");
        }

        //Envia o array $dados com as informações tratadas acima pela estrutura de decisão if
        return $dados;
    }

    public function desativar($cod_unidade, $usuarioLogin) {
        try {
            $sql = "select * from produtos where unid_medida = $cod_unidade and estatus = '' ";

            $retorno = $this->db->query($sql);

            if($retorno->num_rows() > 0) {
                $dados = array('codigo' => 3,
                               'msg' => 'Não podemos desativar, existem produtos associados a esta unidade de medida cadastrados.');
            } else {
                $sql2 = "update unid_medida set estatus = 'D' where cod_unidade = $cod_unidade";

                $this->db->query($sql2);

                if($this->db->affected_rows() > 0) {

                    $this->load->model('M_log');

                    $retorno_log = $this->M_log->inserirLog($usuarioLogin, $sql2);

                    if($retorno_log['codigo'] == 1) {
                        $dados = array('codigo' => 1,
                                       'msg' => 'Unidade de medida desativada corretamente');
                    } else {
                        $dados = array('codigo' => 8,
                                       'msg' => 'Houve algum problema no salvamento do log, porém, a Unidade de medida foi desativada corretamente');
                    }
                } else {
                    $dados = array('codigo' => 7,
                                   'msg' => 'Houve algum problema na desativação da unidade de medida');
                }
            }
        } catch(Exception $e) {
            $dados = array('codigo' => 00,
                           'msg' => 'ATENCAO: O seguinte erro aconteceu ->', $e->getMessage(), "\n");
        }

        //Envia o array $dados com as informações tratadas acima pela estrutura de decisão if
        return $dados;
    }

    public function usuarioExiste($usuarioLogin) {
        $this->db->where('usuario', trim($usuarioLogin));
        $query = $this->db->get('usuarios');
        return $query->num_rows() > 0;
    }
}
?>