<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produto extends CI_Controller {
	//Atributos privados da classe
    private $cod_produto;
    private $descricao;
    private $unidadeMedida;
    private $estoqueMinimo;
    private $estoqueMaximo;
    private $usuarioLogin;

    //Getters dos atributos
    public function getCodProduto()
    {
        return $this->cod_produto;
    }

    public function getDescricao()
    {
        return $this->descricao;
    }

    public function getUnidMedida() 
    {
        return $this->unidadeMedida;
    }

    public function getEstoqueMinimo()
    {
        return $this->estoqueMinimo;
    }

    public function getEstoqueMaximo()
    {
        return $this->estoqueMaximo;
    }

    public function getUsuarioLogin()
    {
        return $this->usuarioLogin;
    }

    //Setters dos atributos
    public function setCodProduto($cod_produtoFront) 
    {
        $this->cod_produto = $cod_produtoFront;
    }

    public function setDescricao($descricaoFront)
    {
        $this->descricao = $descricaoFront;
    }

    public function setUnidMedida($unidadeMedida) 
    {
        $this->unidadeMedida = $unidadeMedida;
    }

    public function setEstoqueMinimo($estoqueMinimoFront)
    {
        $this->estoqueMinimo = $estoqueMinimoFront;
    }

    public function setEstoqueMaximo($estoqueMaximoFront)
    {
        $this->estoqueMaximo = $estoqueMaximoFront;
    }

    public function setUsuarioLogin($usuarioLoginFront)
    {
        $this->usuarioLogin = $usuarioLoginFront;
    }

    public function inserir() {
        try {
            $json = file_get_contents('php://input');
            $resultado = json_decode($json);
    
            //Array com os dados que deverão vir do Front
            $lista = array(
                "descricao" => '0',
                "unidadeMedida" => '0',
                "estoqueMinimo" => '0',
                "estoqueMaximo" => '0',
                "usuarioLogin" => '0'
            );
    
            if(verificarParam($resultado, $lista) == 1) {
                //Fazendo os setters
                $this->setDescricao($resultado->descricao);
                $this->setUnidMedida($resultado->unidadeMedida);
                $this->setEstoqueMinimo($resultado->estoqueMinimo);
                $this->setEstoqueMaximo($resultado->estoqueMaximo);
                $this->setUsuarioLogin($resultado->usuarioLogin);
    
                if(trim($this->getDescricao()) == '') {
                    $retorno = array('codigo' => 2, 'msg' => 'Descrição não informada.');
                } elseif(strlen($this->getDescricao()) > 30) {
                    $retorno = array('codigo' => 3, 'msg' => 'Descrição pode conter no máximo 30 caracteres.');
                } elseif($this->getEstoqueMinimo() < 0) {
                    $retorno = array('codigo' => 4, 'msg' => 'Estoque mínimo não pode ser vazio ou negativo.');
                } elseif($this->getEstoqueMaximo() <= 0 || $this->getEstoqueMaximo() < $this->getEstoqueMinimo()) {
                    $retorno = array('codigo' => 5, 'msg' => 'Estoque máximo inválido ou menor que o estoque mínimo.');
                } elseif(trim($this->getUsuarioLogin()) == '') {
                    $retorno = array('codigo' => 6, 'msg' => 'Usuário não informado.');
                } elseif(trim($this->getUnidMedida()) == '' || $this->getUnidMedida() <= 0) {
                    $retorno = array('codigo' => 7, 'msg' => 'Unidade de medida inválida ou não informada.');
                } else {
                    $this->load->model('M_produto');
    
                    //Verificando se o usuário que está inserindo existe
                    if(!$this->M_produto->usuarioExiste($this->getUsuarioLogin())) {
                        $retorno = array('codigo' => 8, 'msg' => 'Usuário logado no sistema inexistente.');
                    } else {
                        //Verificando se a unidade de medida existe
                        $this->db->where('cod_unidade', $this->getUnidMedida());
                        $query = $this->db->get('unid_medida');
    
                        if($query->num_rows() == 0) {
                            $retorno = array('codigo' => 9, 'msg' => 'Unidade de medida não encontrada.');
                        } else {
                            //Inserindo o produto se todas as validações forem atendidas
                            $retorno = $this->M_produto->inserir(
                                $this->getDescricao(),
                                $this->getUnidMedida(),
                                $this->getEstoqueMinimo(),
                                $this->getEstoqueMaximo(),
                                $this->getUsuarioLogin()
                            );
                        }
                    }
                }
            } else {
                $retorno = array('codigo' => 99,
                                 'msg' => 'Os campos vindos do FrontEnd não representam o método inserir. Verifique.'
                );
            }
        } catch(Exception $e) {
            $retorno = array('codigo' => 0,
                             'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ', $e->getMessage()
            );
        }
    
        //Retorno no formato JSON
        echo json_encode($retorno);
    }

    public function consultar() {
        try {
            $json = file_get_contents('php://input');
            $resultado = json_decode($json);
    
            //Array com os dados que deverão vir do Front
            $lista = array(
                "codigo" => '0',
                "descricao" => '0',
                "estoqueMinimo" => '0',
                "estoqueMaximo" => '0'
            );
    
            if(verificarParam($resultado, $lista) == 1) {
                //Fazendo os setters
                $this->setCodProduto($resultado->codigo);
                $this->setDescricao($resultado->descricao);
                $this->setEstoqueMinimo($resultado->estoqueMinimo);
                $this->setEstoqueMaximo($resultado->estoqueMaximo);
    
                $this->load->model('M_produto');

                $retorno = $this->M_produto->consultar(
                    $this->getCodProduto(),
                    $this->getDescricao(),
                    $this->getEstoqueMinimo(),
                    $this->getEstoqueMaximo()
                );

            } else {
                $retorno = array('codigo' => 99, 
                                 'msg' => 'Os campos vindos do FrontEnd não representam o método consultar. Verifique.');
            }
        } catch(Exception $e) {
            $retorno = array('codigo' => 0,
                             'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ', $e->getMessage());
        }
    
        //Retorno no formato JSON
        echo json_encode($retorno);
    }
    
    public function alterar() {
        try {
            $json = file_get_contents('php://input');
            $resultado = json_decode($json);
    
            //Array com os dados que deverão vir do Front
            $lista = array(
                "codigo" => '0',
                "descricao" => '0',
                "estoqueMinimo" => '0',
                "estoqueMaximo" => '0',
                "usuarioLogin" => '0'
            );
    
            if(verificarParam($resultado, $lista) == 1) {
                //Fazendo os setters
                $this->setCodProduto($resultado->codigo);
                $this->setDescricao($resultado->descricao);
                $this->setEstoqueMinimo($resultado->estoqueMinimo);
                $this->setEstoqueMaximo($resultado->estoqueMaximo);
                $this->setUsuarioLogin($resultado->usuarioLogin);
    
                //Validações dos campos recebidos
                if(trim($this->getCodProduto()) == '' || $this->getCodProduto() == 0) {
                    $retorno = array('codigo' => 2, 'msg' => 'Código não informado.');
                } elseif(trim($this->getDescricao()) == '') {
                    $retorno = array('codigo' => 3, 'msg' => 'Descrição não informada.');
                } elseif($this->getEstoqueMinimo() == '' || $this->getEstoqueMaximo() == '') {
                    $retorno = array('codigo' => 4, 'msg' => 'Estoque mínimo ou estoque máximo não informado.');
                } elseif(trim($this->getUsuarioLogin()) == '') {
                    $retorno = array('codigo' => 5, 'msg' => 'Usuário logado no sistema não informado.');
                } else {
                    //Realizo a instância da Model
                    $this->load->model('M_produto');
    
                    //Atributo $retorno recebe array com informações da alteração dos dados
                    $retorno = $this->M_produto->alterar(
                        $this->getCodProduto(),
                        $this->getDescricao(),
                        $this->getEstoqueMinimo(),
                        $this->getEstoqueMaximo(),
                        $this->getUsuarioLogin()
                    );
                }
            } else {
                $retorno = array('codigo' => 99,
                                 'msg' => 'Os campos vindos do FrontEnd não representam o método de alteração. Verifique.');
            }
        } catch(Exception $e) {
            $retorno = array('codigo' => 0,
                             'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ', $e->getMessage());
        }
    
        //Retorno no formato JSON
        echo json_encode($retorno);
    }
    
    public function desativar() {
        try {
            $json = file_get_contents('php://input');
            $resultado = json_decode($json);
    
            //Array com os dados que deverão vir do Front
            $lista = array(
                "codigo" => '0',
                "usuarioLogin" => '0'
            );
    
            if(verificarParam($resultado, $lista) == 1) {
                //Fazendo os setters
                $this->setCodProduto($resultado->codigo);
                $this->setUsuarioLogin($resultado->usuarioLogin);
    
                if(trim($this->getCodProduto()) == '' || $this->getCodProduto() == 0) {
                    $retorno = array('codigo' => 2, 'msg' => 'Código não informado.');
                } elseif(trim($this->getUsuarioLogin()) == '') {
                    $retorno = array('codigo' => 5, 'msg' => 'Usuário não informado.');
                } else {
                    //Realizo a instância da Model
                    $this->load->model('M_produto');

                    //Atributo $retorno recebe array com informações	
                    $retorno = $this->M_produto->desativar(
                        $this->getCodProduto(),
                        $this->getUsuarioLogin()
                    );
                }
            } else {
                $retorno = array('codigo' => 99,
                                 'msg' => 'Os campos vindos do FrontEnd não representam o método de desativação. Verifique.');
            }
        } catch(Exception $e) {
            $retorno = array('codigo' => 0,
                             'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ', $e->getMessage());
        }
    
        //Retorno no formato JSON
        echo json_encode($retorno);
    }
}