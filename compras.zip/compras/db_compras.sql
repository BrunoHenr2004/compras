# Verifica se o banco de dados 'compras' já existe e o deleta
drop database if exists compras;

#Criação do banco de dados, denominados compras
create database compras;

#Habilitamos a utilização do mesmo
use compras;

#Estrutura da tabela de usuários
create table usuarios (
	id_usuario  integer not null auto_increment primary key,
    usuario		varchar(15) not null,
    senha		varchar(32) not null,
    dtcria		datetime default now(),
    estatus		char(01) default ''
);

#Vamos inserir um usuario padrão do sistema
insert into usuarios (usuario, senha)
values ('admin', md5('admin123'));

#Ao final fazemos um Select para verificar o registro inserido
select * from usuarios where senha = md5('admin123');

#Alterando a tabela de usuários de acordo com a necessidade
alter table usuarios add column nome varchar(30) default '' after senha,
					 add column tipo varchar(20) default '' after estatus;

#Mudando a estrutura da tabela de usuário
alter table usuarios drop column id_usuario;
alter table usuarios modify usuario varchar(15) not null primary key;

#Estrutura da tabela de unidade de medidas
create table unid_medida (
	cod_unidade  integer auto_increment primary key,
    sigla        varchar(03) default '',
    descricao    varchar(30) default '',
    dtcria       datetime default now(),
    usucria      varchar(15) default '',
    estatus      char(01) default '',
    
    constraint foreign key fk_unidmed_prod (usucria) references usuarios(usuario)
);

#Estrutura da tabela de produtos
create table produtos (
	cod_produtos  integer auto_increment primary key,
    descricao     varchar(30) default '',
    unid_medida   integer default 0,
    estoq_minimo  integer default 0,
    estoq_maximo  integer default 0,
    dtcria        datetime default now(),
    usucria       varchar(15) default '',
    estatus       char(01) default '',
    
    constraint foreign key fk_prod_unidmed (unid_medida) references unid_medida(cod_unidade),
    constraint foreign key fk_prod_usuarios (usucria) references usuarios(usuario)
);

SELECT * FROM unid_medida WHERE cod_unidade = 1;
